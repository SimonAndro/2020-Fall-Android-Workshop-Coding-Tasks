package com.ubyte.layoutcodelab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class Attendants extends AppCompatActivity {

    final static String JOINNAME ="joinname";
    final static String JOINSTUDNO ="joinstudentno";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendants);

        String name = (String) getIntent().getExtras().get(JOINNAME);
        String studentNo = (String) getIntent().getExtras().get(JOINSTUDNO);

        //Log.i("input", "user data: "+name + "， "+studentNo);

        AttendantHelper[] oldAttendants = AttendantHelper.Attendants;

        ArrayList<AttendantHelper> newAttendants = new ArrayList<AttendantHelper> (Arrays.asList(oldAttendants));
        newAttendants.add(0, new AttendantHelper(newAttendants.size()+1,name,studentNo));

        ArrayAdapter<AttendantHelper> arrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                newAttendants
        );

        ListView listView = (ListView)findViewById(R.id.id_listview_attendants);
        listView.setAdapter(arrayAdapter);

    }
}