package com.ubyte.layoutcodelab;

public class AttendantHelper {
    final static AttendantHelper[] Attendants = {
            new AttendantHelper(28, " Moon Cake        ", "  6658773577"),
            new AttendantHelper(27, " Enrique West     ", "  8582700617"),
            new AttendantHelper(26, " Damien Braun     ", "  4113674062"),
            new AttendantHelper(25, " Ellie Osborne    ", "  8373122815"),
            new AttendantHelper(24, " Cierra Vegae     ", "  1622737449"),
            new AttendantHelper(23, " Alden Cantrell   ", "  0038341717"),
            new AttendantHelper(22, " Kierra Gentry    ", "  5071786790"),
            new AttendantHelper(21, " Pierre Cox       ", "  2446486879"),
            new AttendantHelper(20, " 张三               ", "8609412135"),
            new AttendantHelper(19, " 张一               ", "4694829054"),
            new AttendantHelper(18, " Waneta Cripe     ", "  6422532700"),
            new AttendantHelper(17, " Laraine Bundrick ", "  5221099248"),
            new AttendantHelper(16, " Cleotilde Seedorf", "  4957209795"),
            new AttendantHelper(15, " Lucius Fonte     ", "  1900965047"),
            new AttendantHelper(14, " Byron Rotolo     ", "  0995559113"),
            new AttendantHelper(13, " Lynell Cronin    ", "  9679347496"),
            new AttendantHelper(12, " Alejandro Russel ", "  6751113249"),
            new AttendantHelper(11, " Tenesha Perkins  ", "  2500204389"),
            new AttendantHelper(10, " Emilee Marmolejo ", "  4113894342"),
            new AttendantHelper(9, "oraya Reily       ", "862522427"),
            new AttendantHelper(8, "iriam Goodwyn     ", "479771548"),
            new AttendantHelper(7, "orsey Aaronson    ", "744528464"),
            new AttendantHelper(6, "eanice Prim       ", "544205110"),
            new AttendantHelper(5, "taci Gomer        ", "798540578"),
            new AttendantHelper(4, "isha Feth         ", "476399325"),
            new AttendantHelper(3, "ebrah Mathes      ", "807154666"),
            new AttendantHelper(2, "unny Osuna        ", "496979659"),
            new AttendantHelper(1, "arline Danks      ", "137481706")

    };
    private int regNo;
    private String studNo;
    private String name;

    public AttendantHelper(int regno, String name, String studno) {
        this.regNo = regno;
        this.studNo = studno;
        this.name = name;
    }

    @Override
    public String toString() {
        return Integer.toString(regNo) + ". " + this.name + ", " + this.studNo;
    }
}
