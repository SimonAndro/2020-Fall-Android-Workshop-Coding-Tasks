package com.ubyte.layoutcodelab;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class JoinWorkShop extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_work_shop);
    }

    public void joinNow(View view) {
        //get inputted name
        EditText nameET = (EditText)findViewById(R.id.id_name_join);
        String name = nameET.getText().toString().trim();
        if(name.length()==0)// empty string
        {
            Toast.makeText(getApplicationContext(),
                    "Please Enter name",Toast.LENGTH_SHORT).show();
            return;
        }

        // get student number
        EditText studNoET = (EditText)findViewById(R.id.id_studno_join);
        String studNo = studNoET.getText().toString().trim();
        if(studNo.length()==0)// empty string
        {
            Toast.makeText(getApplicationContext(),
                    "Please Enter student number",Toast.LENGTH_SHORT).show();
            return;
        }

        //check if one of the radios is selected
        RadioGroup expRG = (RadioGroup)findViewById(R.id.id_radio_group_exp);
       int checkedID = expRG.getCheckedRadioButtonId();
        if(checkedID == -1)
        {
            Toast.makeText(getApplicationContext(),
                    "Please select programming experience",Toast.LENGTH_SHORT).show();
            return;
        }

        //check if the check box is checked
        CheckBox checkBox = (CheckBox)findViewById(R.id.id_conds) ;
        if(!checkBox.isChecked())
        {
            Toast.makeText(getApplicationContext(),
                    "You should agree to our terms and conditions",Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(getApplicationContext(), Attendants.class);
        intent.putExtra(Attendants.JOINNAME,name);
        intent.putExtra(Attendants.JOINSTUDNO,studNo);
        startActivity(intent);
    }

}