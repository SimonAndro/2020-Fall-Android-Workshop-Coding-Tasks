package com.ubyte.layoutcodelab;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class InviteFriend extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invite_friend);
    }

    public void emailInvite(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("mailto:"));
        startActivity(intent);
    }

    public void smsInvite(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:"));
        startActivity(intent);

    }

    public void callInvite(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:"));
        startActivity(intent);
    }
}