package com.ubyte.layoutcodelab;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /*
     * go to join work shop activity*/
    public void joinWorkShop(View view)
    {
        Intent intent = new Intent(getApplicationContext(), JoinWorkShopActivity.class);
        startActivity(intent);
    }
    /*
    * go to invite friend activity*/
    public void inviteFriend(View view)
    {
        Intent intent = new Intent(getApplicationContext(), InviteFriendActivity.class);
        startActivity(intent);
    }
}