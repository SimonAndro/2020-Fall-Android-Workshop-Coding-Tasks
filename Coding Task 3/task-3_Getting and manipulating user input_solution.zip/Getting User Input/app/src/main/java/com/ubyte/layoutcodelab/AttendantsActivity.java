package com.ubyte.layoutcodelab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class AttendantsActivity extends AppCompatActivity {

    public static final String EXTRA_ATTENDANT_NAME = "attendantName";
    public static final String EXTRA_ATTENDANT_STUD_NO = "attendantStudNum";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendants);

        // retrieve intent data
        String addName = (String)getIntent().getExtras().get(EXTRA_ATTENDANT_NAME);
        String addStudNum = (String)getIntent().getExtras().get(EXTRA_ATTENDANT_STUD_NO);

        // initialze array lis
        ArrayList<Attendant> workShopAttendants =
                new ArrayList<>(Arrays.asList(Attendant.workShopAttendants));
        // add intent data to array list
        workShopAttendants.add(0,
                new Attendant(addName,addStudNum,workShopAttendants.size()+1));
        // pass data to adapter
        ArrayAdapter<Attendant> listAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                workShopAttendants
        );
        //pass data to list view
        ListView listAttendants = (ListView)findViewById(R.id.id_attendants);
        listAttendants.setAdapter(listAdapter);
    }
}