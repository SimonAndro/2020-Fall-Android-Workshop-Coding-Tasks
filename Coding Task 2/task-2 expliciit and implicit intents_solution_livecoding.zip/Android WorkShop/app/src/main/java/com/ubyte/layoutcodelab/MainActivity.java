package com.ubyte.layoutcodelab;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void joinWorkShop(View view) {
        Intent intent = new Intent(getApplicationContext(),JoinWorksopActivity.class);
        startActivity(intent);
    }

    public void inviteFriend(View view) {
      Intent intent = new Intent(getApplicationContext(),InviteFriendActivity.class);
      startActivity(intent);
   }
}