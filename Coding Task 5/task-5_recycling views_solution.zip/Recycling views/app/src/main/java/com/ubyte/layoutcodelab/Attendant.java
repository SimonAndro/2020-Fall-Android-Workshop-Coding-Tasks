package com.ubyte.layoutcodelab;

public class Attendant {
    final static Attendant[] workShopAttendants={
          new Attendant("Moon Cake","6658773577",  28),
          new Attendant("Enrique West","8582700617",27),
          new Attendant("Damien Braun","4113674062",26),
          new Attendant("Ellie Osborne","8373122815",25),
          new Attendant("Cierra Vegae","1622737449",24),
          new Attendant("Alden Cantrell","0038341717",23),
          new Attendant("Kierra Gentry","5071786790",22),
          new Attendant("Pierre Cox","2446486879",21),
          new Attendant("张三","8609412135",20),
          new Attendant("张一","4694829054",19),
          new Attendant("Waneta Cripe","6422532700",18),
          new Attendant("Laraine Bundrick","5221099248",17),
          new Attendant("Cleotilde Seedorf","4957209795",16),
          new Attendant("Lucius Fonte","1900965047",15),
          new Attendant("Byron Rotolo","0995559113",14),
          new Attendant("Lynell Cronin","9679347496",13),
          new Attendant("Alejandro Russel","6751113249",12),
          new Attendant("Tenesha Perkins","2500204389",11),
          new Attendant("Emilee Marmolejo","4113894342",10),
          new Attendant("Soraya Reily","7862522427",9),
          new Attendant("Miriam Goodwyn","6479771548",8),
          new Attendant("Dorsey Aaronson","2744528464",7),
          new Attendant("Jeanice Prim","4544205110",6),
          new Attendant("Staci Gomer","2798540578",5),
          new Attendant("Nisha Feth","4476399325",4),
          new Attendant("Debrah Mathes","6807154666",3),
          new Attendant("Bunny Osuna","5496979659",2),
          new Attendant("Earline Danks","1137481706",1),
    };

    private String name;
    private String studentNo;
    private int regNo;

    public Attendant(String name, String studNo, int regNo)
    {
        this.name = name;
        this.studentNo = studNo;
        this.regNo = regNo;
    }

    public int getRegNo() {
        return regNo;
    }

    public String getName() {
        return name;
    }

    public String getStudentNo() {
        return studentNo;
    }

    public String toString()
    {
        return  Integer.toString(this.regNo)+". "+this.name+", "+this.studentNo;
    }
}


