package com.ubyte.layoutcodelab;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.Locale;

public class AttendantDataAdapter extends RecyclerView.Adapter<AttendantDataAdapter.ViewHolder> {

    private int[] regNos;
    private String[] names;
    private  String[] studNos;

    public AttendantDataAdapter(int[] regNos, String[] names, String[] studNos)
    {
        this.regNos = regNos;
        this.names = names;
        this.studNos = studNos;
    }
    public static  class ViewHolder extends RecyclerView.ViewHolder {
        //defining the view for the data

        private CardView cardView;

        public ViewHolder(CardView v) {
            super(v);
            cardView = v;
        }
    }


    @Override
    public AttendantDataAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // initialize the view holder here

        CardView cv = (CardView) LayoutInflater.from(parent.getContext()).
                inflate(R.layout.attendant_card_view,parent,false);
        return new ViewHolder(cv);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int position) {
        CardView cardView = viewHolder.cardView;
        TextView regNoTV = (TextView)cardView.findViewById(R.id.id_attendant_reg_num);
        regNoTV.setText(String.format(Locale.getDefault(),"%d",regNos[position]));
        TextView nameTV = (TextView)cardView.findViewById(R.id.id_attendant_name);
        nameTV.setText(names[position]);
        TextView studNumTV = (TextView)cardView.findViewById(R.id.id_attendant_stud_no);
        studNumTV.setText(studNos[position]);
    }

    @Override
    public int getItemCount() {
        return regNos.length;
    }
}
