package com.ubyte.layoutcodelab;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.GridLayout;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class AttendantsActivity extends AppCompatActivity {

    public static final String EXTRA_ATTENDANT_NAME = "attendantName";
    public static final String EXTRA_ATTENDANT_STUD_NO = "attendantStudNum";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendants);

        // initialize array list
        ArrayList<Attendant> workShopAttendants =
                new ArrayList<>(Arrays.asList(Attendant.workShopAttendants));

        if(getIntent().getExtras()!=null) {
            // retrieve intent data
            String addName = (String) getIntent().getExtras().get(EXTRA_ATTENDANT_NAME);
            String addStudNum = (String) getIntent().getExtras().get(EXTRA_ATTENDANT_STUD_NO);

            // add intent data to array list
            workShopAttendants.add(0,
                    new Attendant(addName, addStudNum, workShopAttendants.size() + 1));
        }

        // pass data to adapter
        int[] regNos = new int[workShopAttendants.size()];
        String[] names = new String[workShopAttendants.size()];
        String[] studNos = new String[workShopAttendants.size()];

        for(int i = 0; i<workShopAttendants.size(); i++)
        {
            regNos[i] = workShopAttendants.get(i).getRegNo();
            names[i] = workShopAttendants.get(i).getName();
            studNos[i] = workShopAttendants.get(i).getStudentNo();
        }
        AttendantDataAdapter attendantDataAdapter = new AttendantDataAdapter(regNos,names,studNos);
        //pass data to recycler view
        RecyclerView attendantsRecycler = (RecyclerView)findViewById(R.id.id_attendants);
        LinearLayoutManager  layoutManager = new LinearLayoutManager(this);
        attendantsRecycler.setLayoutManager(layoutManager);
        attendantsRecycler.setAdapter(attendantDataAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // inflate the menu (to add items to the app bar)
        getMenuInflater().inflate(R.menu.attendants_menu, menu);

        //Color the menu icons
        for(int i =0; i<menu.size(); i++)
        {
            Drawable drawable = menu.getItem(i).getIcon();
            if(drawable!=null)
            {
                drawable.mutate();
                drawable.setColorFilter(getResources().getColor(R.color.headerBelt),
                        PorterDuff.Mode.SRC_ATOP);
            }
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.id_menu_join_now:
                // go to join workshop activity
                Intent intentJoin = new Intent(getApplicationContext(), JoinWorkShopActivity.class);
                startActivity(intentJoin);
                return true;

            case R.id.id_menu_invite_friend:
                // go to invite friend activity
                Intent intentInvite = new Intent(getApplicationContext(), InviteFriendActivity.class);
                startActivity(intentInvite);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}