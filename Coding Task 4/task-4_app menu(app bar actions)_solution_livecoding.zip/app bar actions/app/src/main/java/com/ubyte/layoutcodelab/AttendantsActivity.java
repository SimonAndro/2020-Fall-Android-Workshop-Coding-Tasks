package com.ubyte.layoutcodelab;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class AttendantsActivity extends AppCompatActivity {

    public static final String EXTRA_ATTENDANT_NAME = "attendantName";
    public static final String EXTRA_ATTENDANT_STUD_NO = "attendantStudNum";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendants);

        // initialze array lis
        ArrayList<Attendant> workShopAttendants =
                new ArrayList<>(Arrays.asList(Attendant.workShopAttendants));

        // retrieve intent data
        if(getIntent().getExtras()!=null)
        {
            String addName = (String)getIntent().getExtras().get(EXTRA_ATTENDANT_NAME);
            String addStudNum = (String)getIntent().getExtras().get(EXTRA_ATTENDANT_STUD_NO);

            // add intent data to array list
            workShopAttendants.add(0,
                    new Attendant(addName,addStudNum,workShopAttendants.size()+1));

        }
        // pass data to adapter
        ArrayAdapter<Attendant> listAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                workShopAttendants
        );
        //pass data to list view
        ListView listAttendants = (ListView)findViewById(R.id.id_attendants);
        listAttendants.setAdapter(listAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        //inflate the menu , add items to the menu bar
        getMenuInflater().inflate(R.menu.menu_attendants,menu);

        //color icons

        for(int i =0; i<menu.size(); i++)
        {
            Drawable drawable = menu.getItem(i).getIcon();
            if(drawable!=null)
            {

                drawable.mutate();
                drawable.setColorFilter(getResources().getColor(R.color.headerBelt),
                        PorterDuff.Mode.SRC_ATOP);
            }

        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.id_menu_join_now:
                Intent intent1 = new Intent(getApplicationContext(), JoinWorkShopActivity.class);
                startActivity(intent1);
                return true;

            case R.id.id_menu_invite_friend:
                Intent intent2 = new Intent(getApplicationContext(), InviteFriendActivity.class);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}