package com.ubyte.layoutcodelab;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /*
     * go to join work shop activity*/
    public void joinWorkShop(View view)
    {
        Intent intent = new Intent(getApplicationContext(), JoinWorkShopActivity.class);
        startActivity(intent);
    }
    /*
    * go to invite friend activity*/
    public void inviteFriend(View view)
    {
        Intent intent = new Intent(getApplicationContext(), InviteFriendActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        //inflate the menu , add items to the menu bar
        getMenuInflater().inflate(R.menu.menu_main,menu);

        //color icons

        for(int i =0; i<menu.size(); i++)
        {
            Drawable drawable = menu.getItem(i).getIcon();
            if(drawable!=null)
            {

                drawable.mutate();
                drawable.setColorFilter(getResources().getColor(R.color.headerBelt),
                        PorterDuff.Mode.SRC_ATOP);
            }

        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.id_menu_attending_now:
                // Start intent
                Intent intent = new Intent(getApplicationContext(), AttendantsActivity.class);
                startActivity(intent);
                return true;
            case R.id.id_menu_about:
                // show ialog
                AlertDialog alertDialog = new AlertDialog.Builder(
                        MainActivity.this).create();

                alertDialog.setTitle("Android WorkShop");
                alertDialog.setMessage("This is the android workshop app, for joining and inviting friends to join the workshop");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertDialog.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}