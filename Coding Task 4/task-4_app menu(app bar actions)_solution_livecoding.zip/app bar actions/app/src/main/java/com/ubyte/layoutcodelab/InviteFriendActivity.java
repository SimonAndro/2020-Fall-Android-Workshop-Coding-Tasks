package com.ubyte.layoutcodelab;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class InviteFriendActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invite_friend);
    }

    public void emailInvite(View view) {

        List<String> validData = validateInput();

        if(validData.isEmpty()) return;

        String name = validData.get(0);
        String contact = validData.get(1);
        String email = validData.get(2);

        String[] addresses = {email};
        String subject = "Invitation to the Android Workshop";
        String body = "hey " + name +", come and join the Android workshop scheduled October " +
                "1st to 8th. By the way it is fully online.";

        Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT,subject);
        intent.putExtra(Intent.EXTRA_TEXT,body);

        if(intent.resolveActivity(getPackageManager())!=null)
            startActivity(intent);
    }

    public void smsInvite(View view) {
        List<String> validData = validateInput();

        if(validData.isEmpty()) return;

        String name = validData.get(0);
        String contact = validData.get(1);

        String body = "hey " + name +", come and join the Android workshop scheduled October " +
                "1st to 8th. By the way it is fully online.";

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:"+contact));
        intent.putExtra("sms_body",body);

        if(intent.resolveActivity(getPackageManager())!=null)
            startActivity(intent);

    }

    public void callInvite(View view) {

        List<String> validData = validateInput();

        if(validData.isEmpty()) return;

        String contact = validData.get(1);

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:"+contact));
        if(intent.resolveActivity(getPackageManager())!=null)
            startActivity(intent);
    }

    private List<String> validateInput()
    {
        List<String> validData = new ArrayList<String>();

        // get inputted name
        EditText nameEditText = (EditText)findViewById(R.id.edit_enter_name_invite);
        String friendName = nameEditText.getText().toString().trim();

        if(friendName.length()==0)
        {
            Toast.makeText(getApplicationContext(),"Please enter name",
                    Toast.LENGTH_SHORT).show();
            return validData;
        }

        //get inputted contact
        EditText contactEditText = (EditText)findViewById(R.id.edit_enter_contact_invite);
        String friendContact = contactEditText.getText().toString().trim();

        if(friendContact.length()==0)
        {
            Toast.makeText(getApplicationContext(),"Please enter contact",
                    Toast.LENGTH_SHORT).show();
            return validData;
        }

        //get inputted email
        EditText emailEditText = (EditText)findViewById(R.id.edit_enter_email_invite);
        String friendEmail = emailEditText.getText().toString().trim();

        if(friendEmail.length()==0)
        {
            Toast.makeText(getApplicationContext(),"Please enter email",
                    Toast.LENGTH_SHORT).show();
            return validData;
        }

        // return valid data list
        validData.add(friendName);
        validData.add(friendContact);
        validData.add(friendEmail);

        return  validData;
    }
}

