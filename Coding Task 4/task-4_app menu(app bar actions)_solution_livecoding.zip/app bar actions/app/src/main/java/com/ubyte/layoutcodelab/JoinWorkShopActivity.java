package com.ubyte.layoutcodelab;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class JoinWorkShopActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_work_shop);
    }

    public void joinNow(View view) {
        //get name
        EditText nameView = (EditText)findViewById(R.id.edit_enter_name);
        String userName = nameView.getText().toString().trim();
        if(userName.length()==0) // empty string
        {
            Toast.makeText(getApplicationContext(),"Please enter name",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        //get student number
        EditText studNumView = (EditText)findViewById(R.id.edit_enter_stud_no);
        String studNum = studNumView.getText().toString().trim();
        if(studNum.length()==0) // empty string
        {
            Toast.makeText(getApplicationContext(),"Please enter Student number",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        //get programming experience
        RadioGroup radioGroup = (RadioGroup)findViewById(R.id.prog_exp_radio);
        int id = radioGroup.getCheckedRadioButtonId();
        if(id == -1)
        {
            Toast.makeText(getApplicationContext(),"Please select programming Experience",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        //terms and conditions check box
        CheckBox checkBox = (CheckBox)findViewById(R.id.id_i_agree);
        if(!checkBox.isChecked())
        {
            Toast.makeText(getApplicationContext(),"You need to agree to the terms and Conditions " +
                            "before continuing",
                    Toast.LENGTH_LONG).show();
            return;
        }

        // Start intent
        Intent intent = new Intent(getApplicationContext(), AttendantsActivity.class);
        intent.putExtra(AttendantsActivity.EXTRA_ATTENDANT_NAME,userName);
        intent.putExtra(AttendantsActivity.EXTRA_ATTENDANT_STUD_NO,studNum);
        startActivity(intent);
    }

}